# Reproducibility bundle - Prevalence of Functional Iron Deficiency Among US Adults: A Cross-Sectional Analysis of NHANES 2017-March 2020 pre-pandemic

* Plan `plan_65210279ed` v1, sha256 `c77b1e7d6614f6fce2957ab48361e476422b7aeb349dc06dc1248e0e454f869b`
* Run `run_040e159c` (synthetic)
* `Rscript reproduce.R` re-executes the analysis and asserts the primary estimate matches.
* `provenance.json` is a hash-chained ledger of every human and AI action.
